module.exports = {
    plugins: {
      '@tailwindcss/postcss': {}, // New required plugin for Tailwind 4.0
      autoprefixer: {},
    },
  };