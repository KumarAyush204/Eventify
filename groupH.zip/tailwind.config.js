/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./views/**/*.ejs"], // Adjust based on your EJS file locations
    theme: {
      extend: {},
    },
    plugins: [],
  };
  